# Flower Segmentation
# Group 3

import cv2
from matplotlib import pyplot as plt

### INPUT
def processing_and_saving_images(input_image_paths, pipeline_folder):
    for index, image_path in enumerate(input_image_paths):
        # Read input image
        img = cv2.imread(image_path)

        # Convert colorspace RGB to LAB
        lab_img = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        L, A, B = cv2.split(lab_img)

        # Define image processing pipeline folder locations for each input image
        pipeline_folder_output = f'{pipeline_folder}{index + 1}/'
        L_out = pipeline_folder_output + 'L/'
        A_out = pipeline_folder_output + 'A/'
        B_out = pipeline_folder_output + 'B/'

        # writing the initial L.A.B images to the image processing pipeline
        cv2.imwrite(f'{L_out}1_L_out.jpg', L)
        cv2.imwrite(f'{A_out}1_A_out.jpg', A)
        cv2.imwrite(f'{B_out}1_B_out.jpg', B)

        ### PREPROCESSING
        # 5x5 median filtering
        L_median = cv2.medianBlur(L, 5)
        A_median = cv2.medianBlur(A, 5)
        B_median = cv2.medianBlur(B, 5)

        # writing the median L.A.B images to the image processing pipeline
        cv2.imwrite(f'{L_out}2_L_median.jpg', L_median)
        cv2.imwrite(f'{A_out}2_A_median.jpg', A_median)
        cv2.imwrite(f'{B_out}2_B_median.jpg', B_median)

        #equalizing the images
        L_equalized = cv2.equalizeHist(L_median)
        A_equalized = cv2.equalizeHist(A_median)
        B_equalized = cv2.equalizeHist(B_median)

        # writing the equalized L.A.B images to the image processing pipeline
        cv2.imwrite(f'{L_out}4_L_equalized.jpg', L_equalized)
        cv2.imwrite(f'{A_out}4_A_equalized.jpg', A_equalized)
        cv2.imwrite(f'{B_out}4_B_equalized.jpg', B_equalized)

        ### OTSU
        # Segmenting the foreground from background
        _, L_otsu = cv2.threshold(L_median, 150, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        _, A_otsu = cv2.threshold(A_median, 150, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        _, B_otsu = cv2.threshold(B_median, 150, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # writing the segmented OTSU L.A.B images to the image processing pipeline
        cv2.imwrite(f'{L_out}3_L_otsu.jpg', L_otsu)
        cv2.imwrite(f'{A_out}3_A_otsu.jpg', A_otsu)
        cv2.imwrite(f'{B_out}3_B_otsu.jpg', B_otsu)


        ### FINAL OUTPUT
        # show otsu images (for testing threshold)
        #cv2.imshow('L', L_otsu)
        #cv2.imshow('A', A_otsu)
        #cv2.imshow('B', B_otsu)

## Define input image paths and output folder prefix
# input images path
easy_image_paths = ['dataset/input_images/easy/easy_1.jpg', 'dataset/input_images/easy/easy_2.jpg', 'dataset/input_images/easy/easy_3.jpg']
medium_input_paths = ['dataset/input_images/medium/medium_1.jpg', 'dataset/input_images/medium/medium_2.jpg', 'dataset/input_images/medium/medium_3.jpg']
hard_input_paths = ['dataset/input_images/hard/hard_1.jpg', 'dataset/input_images/hard/hard_2.jpg', 'dataset/input_images/hard/hard_3.jpg']
#output folder (not final output)
easy_pipeline_folder = 'imageprocessing-pipeline/easy/easy'
medium_pipeline_folder = 'imageprocessing-pipeline/medium/medium'
hard_pipeline_folder = 'imageprocessing-pipeline/hard/hard'


# Process and save images (calling the function)
# all easy input images stages put into images processing pipeline folder
processing_and_saving_images(easy_image_paths, easy_pipeline_folder)
# all medium input images stages put into images processing pipeline folder
processing_and_saving_images(medium_input_paths, medium_pipeline_folder)
# all hard input images stages put into images processing pipeline folder
processing_and_saving_images(hard_input_paths, hard_pipeline_folder)

### POSTPROCESSING
# insert postprocessing pipeline here
#
#

# writing the postprocessed L.A.B images to the image processing pipeline
# cv2.imwrite(L_out + '4_L_postprocessed.jpg', L_postprocessed)
# cv2.imwrite(A_out + '4_A_postprocessed.jpg', A_postprocessed)
# cv2.imwrite(B_out + '4_B_postprocessed.jpg', B_postprocessed)


# writing the final output L.A.B images to the output folder (after postprocessing)
# cv2.imwrite(L_final_out + '5_L_postprocessed.jpg', L_postprocessed)
# cv2.imwrite(A_final_out + '5_A_postprocessed.jpg', A_postprocessed)
# cv2.imwrite(B_final_out + '5_B_postprocessed.jpg', B_postprocessed)

# keep windows open
cv2.waitKey(0)
cv2.destroyAllWindows()
